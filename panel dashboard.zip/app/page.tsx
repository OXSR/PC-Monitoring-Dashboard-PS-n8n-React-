"use client"

import { useEffect, useState, useRef } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Badge } from "@/components/ui/badge"
import {
  Activity,
  Cpu,
  HardDrive,
  Monitor,
  Wifi,
  Clock,
  Server,
  Zap,
  Bell,
  BellOff,
  Palette,
  TrendingUp,
  BarChart3,
  Maximize2,
  Timer,
} from "lucide-react"
import { XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Area, AreaChart } from "recharts"

interface SystemData {
  id: number
  createdAt: string
  updatedAt: string
  user_name: string
  machine_name: string
  collected_at: string
  manufacturer: string
  model: string
  os_caption: string
  os_version: string
  os_build_number: string
  os_architecture: string
  active_process: string | null
  active_title: string
  cpu_name: string
  cpu_logical_processors: number
  ram_total_mb: number
  ram_free_mb: number
  ram_used_mb: number
  wifi_ssid: string
  ram_used_pct: string
  ip_hint: string | null
}

interface HistoricalDataPoint {
  time: string
  ramUsed: number
  ramFree: number
  timestamp: number
}

interface Statistics {
  avgRamUsed: number
  maxRamUsed: number
  minRamUsed: number
  avgRamPercent: number
}

type Theme = "default" | "cyberpunk" | "matrix" | "neon" | "minimal"

export default function SystemMonitorDashboard() {
  const [data, setData] = useState<SystemData | null>(null)
  const [isOnline, setIsOnline] = useState(false)
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [refreshInterval, setRefreshInterval] = useState(10)
  const [timeUntilNextUpdate, setTimeUntilNextUpdate] = useState(10)

  const [historicalData, setHistoricalData] = useState<HistoricalDataPoint[]>([])
  const [statistics, setStatistics] = useState<Statistics>({
    avgRamUsed: 0,
    maxRamUsed: 0,
    minRamUsed: 0,
    avgRamPercent: 0,
  })
  const [notificationsEnabled, setNotificationsEnabled] = useState(false)
  const [theme, setTheme] = useState<Theme>("default")
  const [isFullscreen, setIsFullscreen] = useState(false)
  const [particles, setParticles] = useState<Array<{ id: number; x: number; y: number; size: number; speed: number }>>(
    [],
  )
  const canvasRef = useRef<HTMLCanvasElement>(null)

  const requestNotificationPermission = async () => {
    if ("Notification" in window) {
      const permission = await Notification.requestPermission()
      if (permission === "granted") {
        setNotificationsEnabled(true)
        new Notification("Notificaciones Activadas", {
          body: "Recibirás alertas cuando el uso de recursos sea crítico",
          icon: "/favicon.ico",
        })
      }
    }
  }

  const sendNotification = (title: string, body: string) => {
    if (notificationsEnabled && "Notification" in window && Notification.permission === "granted") {
      new Notification(title, { body, icon: "/favicon.ico" })
    }
  }

  const calculateStatistics = (history: HistoricalDataPoint[]) => {
    if (history.length === 0) return

    const ramUsedValues = history.map((d) => d.ramUsed)
    const avgRamUsed = ramUsedValues.reduce((a, b) => a + b, 0) / ramUsedValues.length
    const maxRamUsed = Math.max(...ramUsedValues)
    const minRamUsed = Math.min(...ramUsedValues)

    if (data) {
      const avgRamPercent = (avgRamUsed / data.ram_total_mb) * 100
      setStatistics({ avgRamUsed, maxRamUsed, minRamUsed, avgRamPercent })
    }
  }

  const generateParticles = (ramPercent: number) => {
    const particleCount = Math.floor(ramPercent / 10)
    const newParticles = Array.from({ length: particleCount }, (_, i) => ({
      id: Date.now() + i,
      x: Math.random() * 100,
      y: Math.random() * 100,
      size: Math.random() * 3 + 1,
      speed: Math.random() * 2 + 1,
    }))
    setParticles(newParticles)
  }

  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas || particles.length === 0) return

    const ctx = canvas.getContext("2d")
    if (!ctx) return

    canvas.width = canvas.offsetWidth
    canvas.height = canvas.offsetHeight

    let animationFrameId: number
    const particlePositions = particles.map((p) => ({ ...p }))

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height)

      particlePositions.forEach((particle, index) => {
        particle.y += particle.speed * 0.5
        if (particle.y > 100) particle.y = 0

        const x = (particle.x / 100) * canvas.width
        const y = (particle.y / 100) * canvas.height

        ctx.beginPath()
        ctx.arc(x, y, particle.size, 0, Math.PI * 2)

        const gradient = ctx.createRadialGradient(x, y, 0, x, y, particle.size * 2)
        gradient.addColorStop(0, getThemeColor(theme))
        gradient.addColorStop(1, "transparent")

        ctx.fillStyle = gradient
        ctx.fill()
      })

      animationFrameId = requestAnimationFrame(animate)
    }

    animate()

    return () => cancelAnimationFrame(animationFrameId)
  }, [particles, theme])

  const getThemeColor = (currentTheme: Theme): string => {
    switch (currentTheme) {
      case "cyberpunk":
        return "rgba(255, 0, 255, 0.6)"
      case "matrix":
        return "rgba(0, 255, 0, 0.6)"
      case "neon":
        return "rgba(0, 255, 255, 0.6)"
      case "minimal":
        return "rgba(100, 100, 100, 0.6)"
      default:
        return "rgba(59, 130, 246, 0.6)"
    }
  }

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen()
      setIsFullscreen(true)
    } else {
      document.exitFullscreen()
      setIsFullscreen(false)
    }
  }

  const fetchData = async () => {
    console.log("[v0] Fetching data from n8n endpoint...")
    try {
      const response = await fetch("https://n8n.srv1034252.hstgr.cloud/webhook/ff454afd-eb30-4d2e-ab13-54c945981f0a")

      if (!response.ok) {
        throw new Error("Failed to fetch data")
      }

      const jsonData = await response.json()
      console.log("[v0] Data fetched successfully:", jsonData.machine_name)
      setData(jsonData)
      setIsOnline(true)
      setLastUpdate(new Date())
      setError(null)
      setTimeUntilNextUpdate(refreshInterval)

      const ramUsedPercent = Number.parseFloat(jsonData.ram_used_pct)

      const newDataPoint: HistoricalDataPoint = {
        time: new Date().toLocaleTimeString("es-ES", { hour: "2-digit", minute: "2-digit", second: "2-digit" }),
        ramUsed: jsonData.ram_used_mb,
        ramFree: jsonData.ram_free_mb,
        timestamp: Date.now(),
      }

      console.log("[v0] Adding new data point:", newDataPoint)

      setHistoricalData((prev) => {
        const updated = [...prev, newDataPoint].slice(-20)
        console.log("[v0] Historical data updated. Total points:", updated.length)
        return updated
      })

      generateParticles(ramUsedPercent)

      if (ramUsedPercent > 85 && notificationsEnabled) {
        sendNotification("Uso Crítico de RAM", `El uso de memoria ha alcanzado ${ramUsedPercent.toFixed(1)}%`)
      }
    } catch (err) {
      console.error("[v0] Error fetching data:", err)
      setError(err instanceof Error ? err.message : "Unknown error")
      setIsOnline(false)
    }
  }

  useEffect(() => {
    console.log("[v0] Setting up fetch interval:", refreshInterval, "seconds")
    fetchData()
    const interval = setInterval(() => {
      console.log("[v0] Interval triggered - fetching data")
      fetchData()
    }, refreshInterval * 1000)

    return () => {
      console.log("[v0] Cleaning up interval")
      clearInterval(interval)
    }
  }, [refreshInterval])

  useEffect(() => {
    const countdownInterval = setInterval(() => {
      setTimeUntilNextUpdate((prev) => {
        if (prev <= 1) {
          return refreshInterval
        }
        return prev - 1
      })
    }, 1000)

    return () => clearInterval(countdownInterval)
  }, [refreshInterval])

  useEffect(() => {
    if (historicalData.length === 0 || !data) return

    console.log("[v0] Calculating statistics for", historicalData.length, "data points")
    const ramUsedValues = historicalData.map((d) => d.ramUsed)
    const avgRamUsed = ramUsedValues.reduce((a, b) => a + b, 0) / ramUsedValues.length
    const maxRamUsed = Math.max(...ramUsedValues)
    const minRamUsed = Math.min(...ramUsedValues)
    const avgRamPercent = (avgRamUsed / data.ram_total_mb) * 100

    setStatistics({ avgRamUsed, maxRamUsed, minRamUsed, avgRamPercent })
    console.log("[v0] Statistics updated:", { avgRamUsed, maxRamUsed, minRamUsed, avgRamPercent })
  }, [historicalData, data])

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleString("es-ES", {
      day: "2-digit",
      month: "2-digit",
      year: "numeric",
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    })
  }

  const getTimeSinceUpdate = () => {
    if (!lastUpdate) return "Nunca"
    const seconds = Math.floor((Date.now() - lastUpdate.getTime()) / 1000)
    if (seconds < 60) return `Hace ${seconds}s`
    return `Hace ${Math.floor(seconds / 60)}m`
  }

  if (error && !data) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <Card className="w-full max-w-md border-destructive">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-destructive">
              <Activity className="h-5 w-5" />
              Error de Conexión
            </CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-muted-foreground">{error}</p>
            <p className="text-sm text-muted-foreground mt-2">Reintentando automáticamente...</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (!data) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="relative">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
            <div className="absolute inset-0 animate-spin rounded-full h-12 w-12 border-b-2 border-primary blur-md opacity-50"></div>
          </div>
          <p className="text-muted-foreground">Cargando datos del sistema...</p>
        </div>
      </div>
    )
  }

  const ramUsedPercent = Number.parseFloat(data.ram_used_pct)

  return (
    <div className={`min-h-screen bg-background p-4 md:p-6 lg:p-8 relative theme-${theme}`}>
      <canvas
        ref={canvasRef}
        className="absolute inset-0 pointer-events-none opacity-30"
        style={{ width: "100%", height: "100%" }}
      />

      <div className="max-w-7xl mx-auto space-y-6 relative z-10">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h1 className="text-3xl font-bold text-foreground flex items-center gap-3">
              <div className="relative">
                <Activity className="h-8 w-8 text-chart-1" />
                <Activity className="h-8 w-8 text-chart-1 absolute inset-0 blur-lg opacity-50 animate-pulse" />
              </div>
              Monitor del Sistema
            </h1>
            <p className="text-muted-foreground mt-1">Monitoreo en tiempo real de {data.machine_name}</p>
          </div>
          <div className="flex items-center gap-3 flex-wrap">
            <div className="flex items-center gap-2 bg-muted/50 rounded-lg p-1">
              <button
                onClick={() => setTheme("default")}
                className={`p-2 rounded transition-colors ${theme === "default" ? "bg-chart-1 text-white" : "hover:bg-muted"}`}
                title="Tema Default"
              >
                <Palette className="h-4 w-4" />
              </button>
              <button
                onClick={() => setTheme("cyberpunk")}
                className={`p-2 rounded transition-colors ${theme === "cyberpunk" ? "bg-pink-500 text-white" : "hover:bg-muted"}`}
                title="Tema Cyberpunk"
              >
                <Zap className="h-4 w-4" />
              </button>
              <button
                onClick={() => setTheme("matrix")}
                className={`p-2 rounded transition-colors ${theme === "matrix" ? "bg-green-500 text-white" : "hover:bg-muted"}`}
                title="Tema Matrix"
              >
                <Activity className="h-4 w-4" />
              </button>
              <button
                onClick={() => setTheme("neon")}
                className={`p-2 rounded transition-colors ${theme === "neon" ? "bg-cyan-500 text-white" : "hover:bg-muted"}`}
                title="Tema Neon"
              >
                <TrendingUp className="h-4 w-4" />
              </button>
              <button
                onClick={() => setTheme("minimal")}
                className={`p-2 rounded transition-colors ${theme === "minimal" ? "bg-gray-500 text-white" : "hover:bg-muted"}`}
                title="Tema Minimal"
              >
                <Monitor className="h-4 w-4" />
              </button>
            </div>

            <button
              onClick={requestNotificationPermission}
              className={`p-2 rounded-lg transition-colors ${notificationsEnabled ? "bg-chart-1 text-white" : "bg-muted hover:bg-muted/80"}`}
              title={notificationsEnabled ? "Notificaciones Activadas" : "Activar Notificaciones"}
            >
              {notificationsEnabled ? <Bell className="h-4 w-4" /> : <BellOff className="h-4 w-4" />}
            </button>

            <button
              onClick={toggleFullscreen}
              className="p-2 rounded-lg bg-muted hover:bg-muted/80 transition-colors"
              title="Pantalla Completa"
            >
              <Maximize2 className="h-4 w-4" />
            </button>

            <Badge variant={isOnline ? "default" : "destructive"} className="text-sm px-3 py-1 relative">
              <span
                className={`inline-block w-2 h-2 rounded-full mr-2 ${isOnline ? "bg-green-500 animate-pulse" : "bg-red-500"}`}
              ></span>
              {isOnline && (
                <span className="absolute inset-0 bg-green-500/20 rounded-full blur-md animate-pulse"></span>
              )}
              {isOnline ? "En Línea" : "Desconectado"}
            </Badge>
            <div className="text-sm text-muted-foreground flex items-center gap-2">
              <Clock className="h-4 w-4" />
              {getTimeSinceUpdate()}
            </div>
          </div>
        </div>

        {/* Interval Control Section */}
        <Card className="border-2 border-chart-1/20 bg-gradient-to-br from-chart-1/5 to-transparent">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-lg">
              <Timer className="h-5 w-5 text-chart-1" />
              Control de Actualización
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <label htmlFor="refresh-interval" className="text-sm text-muted-foreground">
                  Intervalo de Actualización
                </label>
                <span className="text-sm font-semibold text-foreground">{refreshInterval} segundos</span>
              </div>
              <input
                id="refresh-interval"
                type="range"
                min="5"
                max="60"
                step="5"
                value={refreshInterval}
                onChange={(e) => setRefreshInterval(Number(e.target.value))}
                className="w-full h-2 bg-muted rounded-lg appearance-none cursor-pointer accent-chart-1"
              />
              <div className="flex justify-between text-xs text-muted-foreground">
                <span>5s</span>
                <span>30s</span>
                <span>60s</span>
              </div>
            </div>

            <div className="space-y-2">
              <div className="flex justify-between items-center">
                <span className="text-sm text-muted-foreground">Próxima actualización en</span>
                <span className="text-sm font-semibold text-chart-1">{timeUntilNextUpdate}s</span>
              </div>
              <Progress value={(timeUntilNextUpdate / refreshInterval) * 100} className="h-2" />
            </div>
          </CardContent>
        </Card>

        {historicalData.length > 0 && (
          <Card className="border-2 border-chart-2/20 bg-gradient-to-br from-chart-2/5 to-transparent">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <BarChart3 className="h-5 w-5 text-chart-2" />
                Estadísticas de la Sesión
                <span className="text-xs text-muted-foreground ml-auto">{historicalData.length} puntos de datos</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="p-3 rounded-lg bg-muted/50">
                  <p className="text-xs text-muted-foreground">RAM Promedio</p>
                  <p className="text-xl font-bold text-chart-2">{(statistics.avgRamUsed / 1024).toFixed(1)} GB</p>
                  <p className="text-xs text-muted-foreground">{statistics.avgRamPercent.toFixed(1)}%</p>
                </div>
                <div className="p-3 rounded-lg bg-muted/50">
                  <p className="text-xs text-muted-foreground">RAM Máxima</p>
                  <p className="text-xl font-bold text-destructive">{(statistics.maxRamUsed / 1024).toFixed(1)} GB</p>
                </div>
                <div className="p-3 rounded-lg bg-muted/50">
                  <p className="text-xs text-muted-foreground">RAM Mínima</p>
                  <p className="text-xl font-bold text-chart-1">{(statistics.minRamUsed / 1024).toFixed(1)} GB</p>
                </div>
                <div className="p-3 rounded-lg bg-muted/50">
                  <p className="text-xs text-muted-foreground">Puntos de Datos</p>
                  <p className="text-xl font-bold text-foreground">{historicalData.length}</p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {historicalData.length > 0 && (
          <Card className="border-2 border-chart-3/20 bg-gradient-to-br from-chart-3/5 to-transparent">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-lg">
                <TrendingUp className="h-5 w-5 text-chart-3" />
                Historial de Uso de RAM
                <span className="text-xs text-muted-foreground ml-auto">Últimos {historicalData.length} registros</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <AreaChart data={historicalData}>
                  <defs>
                    <linearGradient id="colorUsed" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#ef4444" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="#ef4444" stopOpacity={0.1} />
                    </linearGradient>
                    <linearGradient id="colorFree" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.8} />
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0.1} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#374151" opacity={0.5} />
                  <XAxis dataKey="time" stroke="#9ca3af" fontSize={12} tick={{ fill: "#9ca3af" }} />
                  <YAxis
                    stroke="#9ca3af"
                    fontSize={12}
                    tick={{ fill: "#9ca3af" }}
                    tickFormatter={(value) => `${(value / 1024).toFixed(0)}GB`}
                  />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "#1f2937",
                      border: "1px solid #374151",
                      borderRadius: "8px",
                      color: "#f9fafb",
                    }}
                    formatter={(value: number, name: string) => [
                      `${(value / 1024).toFixed(2)} GB`,
                      name === "ramUsed" ? "RAM Usada" : "RAM Libre",
                    ]}
                    labelStyle={{ color: "#f9fafb" }}
                  />
                  <Area
                    type="monotone"
                    dataKey="ramUsed"
                    stroke="#ef4444"
                    strokeWidth={3}
                    fillOpacity={1}
                    fill="url(#colorUsed)"
                    name="ramUsed"
                  />
                  <Area
                    type="monotone"
                    dataKey="ramFree"
                    stroke="#10b981"
                    strokeWidth={3}
                    fillOpacity={1}
                    fill="url(#colorFree)"
                    name="ramFree"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}

        {/* Main Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Computer Info */}
          <Card className="transition-all hover:shadow-lg hover:shadow-chart-1/20 hover:border-chart-1/30 relative overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-br from-chart-1/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <CardHeader className="relative">
              <CardTitle className="flex items-center gap-2 text-lg">
                <div className="relative">
                  <Monitor className="h-5 w-5 text-chart-1" />
                  <div className="absolute inset-0 blur-md bg-chart-1/30 rounded-full"></div>
                </div>
                Información del Equipo
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 relative">
              <div>
                <p className="text-sm text-muted-foreground">Nombre del Equipo</p>
                <p className="font-semibold text-foreground">{data.machine_name}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Usuario</p>
                <p className="font-semibold text-foreground">{data.user_name}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Fabricante</p>
                <p className="font-semibold text-foreground">{data.manufacturer}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Modelo</p>
                <p className="font-semibold text-foreground">{data.model}</p>
              </div>
            </CardContent>
          </Card>

          {/* Operating System */}
          <Card className="transition-all hover:shadow-lg hover:shadow-chart-2/20 hover:border-chart-2/30 relative overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-br from-chart-2/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <CardHeader className="relative">
              <CardTitle className="flex items-center gap-2 text-lg">
                <div className="relative">
                  <Server className="h-5 w-5 text-chart-2" />
                  <div className="absolute inset-0 blur-md bg-chart-2/30 rounded-full animate-pulse"></div>
                </div>
                Sistema Operativo
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 relative">
              <div>
                <p className="text-sm text-muted-foreground">Sistema</p>
                <p className="font-semibold text-foreground">{data.os_caption}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Versión</p>
                <p className="font-semibold text-foreground">{data.os_version}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Build</p>
                <p className="font-semibold text-foreground">{data.os_build_number}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Arquitectura</p>
                <p className="font-semibold text-foreground">{data.os_architecture}</p>
              </div>
            </CardContent>
          </Card>

          {/* CPU Info */}
          <Card className="transition-all hover:shadow-lg hover:shadow-chart-3/20 hover:border-chart-3/30 relative overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-br from-chart-3/5 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <CardHeader className="relative">
              <CardTitle className="flex items-center gap-2 text-lg">
                <div className="relative">
                  <Cpu className="h-5 w-5 text-chart-3" />
                  <div className="absolute inset-0 blur-md bg-chart-3/30 rounded-full"></div>
                </div>
                Procesador
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 relative">
              <div>
                <p className="text-sm text-muted-foreground">Modelo</p>
                <p className="font-semibold text-foreground text-sm leading-relaxed">{data.cpu_name}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Núcleos Lógicos</p>
                <p className="font-semibold text-foreground text-2xl">{data.cpu_logical_processors}</p>
              </div>
            </CardContent>
          </Card>

          {/* RAM Usage - Full Width */}
          <Card className="md:col-span-2 lg:col-span-2 transition-all hover:shadow-lg hover:shadow-chart-4/20 hover:border-chart-4/30 relative overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-br from-muted/50 to-transparent border border-border/50"></div>
            {ramUsedPercent > 80 && <div className="absolute inset-0 bg-red-500/5 animate-pulse"></div>}
            <CardHeader className="relative">
              <CardTitle className="flex items-center gap-2 text-lg">
                <div className="relative">
                  <HardDrive className="h-5 w-5 text-chart-4" />
                  <div className="absolute inset-0 blur-md bg-chart-4/30 rounded-full"></div>
                </div>
                Memoria RAM
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 relative">
              <div className="grid grid-cols-3 gap-4">
                <div className="relative p-3 rounded-lg bg-gradient-to-br from-muted/50 to-transparent border border-border/50">
                  <p className="text-sm text-muted-foreground">Total</p>
                  <p className="font-semibold text-foreground text-xl">{(data.ram_total_mb / 1024).toFixed(1)} GB</p>
                </div>
                <div className="relative p-3 rounded-lg bg-gradient-to-br from-chart-4/10 to-transparent border border-chart-4/20">
                  <p className="text-sm text-muted-foreground">Usada</p>
                  <p className="font-semibold text-chart-4 text-xl">{(data.ram_used_mb / 1024).toFixed(1)} GB</p>
                  <div className="absolute inset-0 bg-chart-4/5 blur-xl rounded-lg"></div>
                </div>
                <div className="relative p-3 rounded-lg bg-gradient-to-br from-chart-2/10 to-transparent border border-chart-2/20">
                  <p className="text-sm text-muted-foreground">Libre</p>
                  <p className="font-semibold text-chart-2 text-xl">{(data.ram_free_mb / 1024).toFixed(1)} GB</p>
                </div>
              </div>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Uso de Memoria</span>
                  <span className="text-sm font-semibold text-foreground">{ramUsedPercent.toFixed(1)}%</span>
                </div>
                <div className="relative">
                  <Progress value={ramUsedPercent} className="h-3" />
                  {ramUsedPercent > 50 && (
                    <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent animate-shimmer"></div>
                  )}
                </div>
                {ramUsedPercent > 80 && (
                  <p className="text-xs text-destructive flex items-center gap-1 animate-pulse">
                    <Zap className="h-3 w-3" />
                    Uso elevado de memoria
                  </p>
                )}
              </div>
            </CardContent>
          </Card>

          {/* Network Info */}
          <Card className="transition-all hover:shadow-lg hover:shadow-chart-5/20 hover:border-chart-5/30 relative overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-r from-chart-1/5 via-chart-2/5 to-chart-3/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <div className="absolute inset-0 border-2 border-transparent group-hover:border-chart-1/20 rounded-lg transition-colors"></div>
            <CardHeader className="relative">
              <CardTitle className="flex items-center gap-2 text-lg">
                <div className="relative">
                  <Wifi className="h-5 w-5 text-chart-5" />
                  <div className="absolute inset-0 blur-md bg-chart-5/30 rounded-full animate-pulse"></div>
                </div>
                Red
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 relative">
              <div>
                <p className="text-sm text-muted-foreground">SSID WiFi</p>
                <p className="font-semibold text-foreground">{data.wifi_ssid || "No conectado"}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">IP</p>
                <p className="font-semibold text-foreground">{data.ip_hint || "N/A"}</p>
              </div>
            </CardContent>
          </Card>

          {/* Active Window - Full Width */}
          <Card className="md:col-span-2 lg:col-span-3 transition-all hover:shadow-lg hover:shadow-chart-1/20 relative overflow-hidden group">
            <div className="absolute inset-0 bg-gradient-to-r from-chart-1/5 via-chart-2/5 to-chart-3/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
            <div className="absolute inset-0 border-2 border-transparent group-hover:border-chart-1/20 rounded-lg transition-colors"></div>
            <CardHeader className="relative">
              <CardTitle className="flex items-center gap-2 text-lg">
                <div className="relative">
                  <Activity className="h-5 w-5 text-chart-1" />
                  <div className="absolute inset-0 blur-md bg-chart-1/30 rounded-full animate-pulse"></div>
                </div>
                Actividad Actual
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 relative">
              <div>
                <p className="text-sm text-muted-foreground">Ventana Activa</p>
                <p className="font-semibold text-foreground">{data.active_title}</p>
              </div>
              {data.active_process && (
                <div>
                  <p className="text-sm text-muted-foreground">Proceso</p>
                  <p className="font-semibold text-foreground">{data.active_process}</p>
                </div>
              )}
              <div>
                <p className="text-sm text-muted-foreground">Última Actualización</p>
                <p className="font-semibold text-foreground">{formatDate(data.collected_at)}</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
